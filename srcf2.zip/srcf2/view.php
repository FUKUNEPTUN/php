<!DOCTYPE html>
<?php
include "kapcsolat.php";
$adatok = readOne($dbc, 'pizzak', $_GET['id']);
print_r($_GET);
?>


<html>
    <head>
        <meta charset="UTF-8">
        <title>pizzak</title>
        <link href="bootstrap.min.css" rel="stylesheet" type="text/css"/>

    </head>
    <body>
    <div class="container">
            <ul class="list-group">
                <li > id: <?php hiv("id"); ?> </li>
                <li > név: <?php hiv("nev"); ?></li>
                <li > feltét: <?php hiv("feltetek"); ?></li>
                <li > ára: <?php hiv("ar"); ?></li>
                <li > kép: <?php hiv("kep"); ?></li>
            </ul>

            <table class="table table-success table-striped my-3" >





                <a class="btn btn-success" href="index2.php">Vissza</a>


<?php
function hiv($asd){
        $host = 'localhost';
        $dbuser = 'root';
        $password = '';
        $dbname = 'pizzeria'; 
        $id = $_GET['id'];
        // Create connection
        $conn = new mysqli($host, $dbuser, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT * FROM pizzak WHERE id = $id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            echo $row["$asd"];
        }
    }
        $conn->close();
}
?>

                
        </div>
        <script src="bootstrap.min.js" type="text/javascript"></script>
    </body>
</html>