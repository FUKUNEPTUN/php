<!DOCTYPE html>



<html>

<head>
    <meta charset="UTF-8">
    <title>pizzak</title>
    <link href="bootstrap.min.css" rel="stylesheet" type="text/css" />

</head>

<body>
    <div class="container  w-50">
        <form name="f" method="POST">
            <div class="mb-3">
                <label for="nev" class="form-label">Név</label>
                <input type="text" class="form-control" id="nev" name="nev" placeholder="">
            </div>
            <div class="mb-3">
                <label for="feltetek" class="form-label">feltetek</label>
                <input type="text" class="form-control" id="feltetek" name="feltetek" placeholder="">
            </div>
            <div class="mb-3">
                <label for="ar" class="form-label">ár</label>
                <input type="number" class="form-control" id="ar" name="ar" placeholder="">
            </div>
            <div class="mb-3">
                <label for="kep" class="form-label">kép</label>
                <input type="text" class="form-control" id="kep" name="kep" placeholder="">
            </div>
            <input class="btn btn-success" type="submit" name="insert" value="Beszúrás" />
            <a class="btn btn-success" href="index2.php">Vissza</a>

        </form>
        <?php 


  
                if(array_key_exists('insert', $_POST)) {
                    asd();
                }
                        function asd(){                $host = 'localhost';
                $dbuser = 'root';
                $password = '';
                $dbname = 'pizzeria';  
                $nev = htmlspecialchars($_REQUEST['nev']);
                $feltetek = htmlspecialchars($_REQUEST['feltetek']);
                $ar = htmlspecialchars($_REQUEST['ar']);
                $kep = htmlspecialchars($_REQUEST['kep']);
                if ($_SERVER["REQUEST_METHOD"] == "POST") {

                    // Get input field value
                try {
                $conn = new PDO("mysql:host=$host;dbname=$dbname", $dbuser, $password);
                // set the PDO error mode to exception

                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = "INSERT INTO pizzak (`nev`, `feltetek`, `ar`, `kep`)
                VALUES ('$nev', '$feltetek', '$ar', '$kep')";
                // use exec() because no results are returned
                $conn->exec($sql);
                echo "Hozzáadtál egy pizzát";
                } catch(PDOException $e) {
                echo $sql . "<br>" . $e->getMessage();
                }
                }


                $conn = null;
                        }


?>


    </div>
    <script src="../kozos/bootstrap.min.js" type="text/javascript"></script>
</body>

</html>